@extends('admin.layouts.app')
@section('title', 'Dashboard')
@section('head')
@endsection
@section('content')
<div class="app-title">
    <div>
        <h1><i class="fa fa-dashboard"></i> Dashboard</h1>
        <p>Trung tâm gia sư Đà Nẵng</p>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
    </div>
</div>
@endsection
@section('javascript')
<script type="text/javascript" src="/web-admin/template/js/plugins/chart.js">
</script>
@endsection
