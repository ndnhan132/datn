<div class="w-100 bg-light d-flex" style="" id="blank-page">
  <div class="h-100 w-100" style="background: rgba(255,255,255);">
    <div class="d-flex justify-content-center my-auto w-100 h-100">
        <div class="spinner-border my-auto d-none" role="status" style="color: #cdcdcd; ">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
</div>
</div>
<script>
var box = document.getElementById('blank-page');
var offsetTop = box.offsetTop;
box.style.minHeight = (window.innerHeight - offsetTop - 20) + 'px';
</script>
