<div class="">
    <img src="{{ asset('images/support.png')}}" alt="support" class="w-100 px-3">
</div>
