<div id="carouselSlidesOnly" class="carousel slide rounded d-none d-sm-block"
            data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="{{ asset('images/slider-1.jpg') }}" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="{{ asset('images/slider-2.jpg') }}" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="{{ asset('images/slider-3.jpg') }}" class="d-block w-100" alt="...">
                </div>
            </div>
        </div>
