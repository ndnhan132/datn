<?php

namespace App\Repositories\TeacherLevel;

interface TeacherLevelRepositoryInterface
{
    //
}
