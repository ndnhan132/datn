<?php

namespace App\Repositories\Subject;

interface SubjectRepositoryInterface
{
    //
}
