<?php

namespace App\Repositories\Todo;

interface TodoRepositoryInterface
{
    //
}
