<?php

namespace App\Repositories\CourseLevel;

interface CourseLevelRepositoryInterface
{
    //
}
