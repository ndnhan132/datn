<div class="table-responsive">
    <table class="table" id="js-post-table">
    </table>
</div>
