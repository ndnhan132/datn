@isset($title)
    <div class="d-flex py-2 text-primary">
        <i class="fas fa-graduation-cap fa-2x pr-2 pt-1"></i>
        <h5 class="text-uppercase font-weight-normal border-bottom border-primary col mb-auto px-0 text_georgia">
            {{ $title }}
        </h5>
    </div>
@endisset
