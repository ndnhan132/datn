<div class="d-flex justify-content-center px-5 py-2">
    <img src="{{ asset('images/loading256x143removebg.gif')}}" alt="loading..." class="w-100">
</div>
